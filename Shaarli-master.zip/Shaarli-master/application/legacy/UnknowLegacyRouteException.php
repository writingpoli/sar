<?php

declare(strict_types=1);

namespace Shaarli\Legacy;

class UnknowLegacyRouteException extends \Exception
{
}
