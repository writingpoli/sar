<?php

declare(strict_types=1);

namespace Shaarli\Front\Exception;

class CantLoginException extends \Exception
{

}
