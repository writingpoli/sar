<?php

namespace Shaarli\Bookmark\Exception;

class EmptyDataStoreException extends \Exception
{
}
