<?php

declare(strict_types=1);

namespace Shaarli\Bookmark\Exception;

class DatastoreNotInitializedException extends \Exception
{

}
